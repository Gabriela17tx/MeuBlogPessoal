package Generation.MeuBlogPessoal;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MeuBlogPessoalApplication {

	public static void main(String[] args) {
		SpringApplication.run(MeuBlogPessoalApplication.class, args);
	}

}
